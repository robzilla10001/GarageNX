# Coding Standard

## Language & toolchain
C++17. Target toolchain is devkitPro / devkitA64 with libnx.
No new third-party dependencies without an approved task.
Clean-room only: no code copied from GPL/reference projects. Reference for behaviour, not for source.

## Portability
Platform-specific code is guarded by PLATFORM_SWITCH.
Prefer libnx APIs for on-device services (nifm, setsys, ncm, es, fs).
Do not rely on Linux/glibc-only symbols (e.g. gethostid, gethostname, INADDR_LOOPBACK); newlib does not provide them.

## Structure
Sources are listed explicitly in CMakeLists.txt. A new source file requires a CMakeLists.txt edit and a cmake reconfigure.
One module per concern. Headers declare; .cpp defines.
File layout mirrors source/<area>/<module>.{hpp,cpp}.

## Errors & resources
Check libnx Result with R_SUCCEEDED / R_FAILED; never ignore an import/register result.
Surface failures to the caller; do not swallow them.
Own threads and sockets via RAII or explicit stop()/close() on every path.
Cross-thread state uses std::atomic or a mutex; document the invariant.

## Style
Formatting is enforced by .clang-format (LLVM base, 4-space, 100 col, Type* name). Do not hand-format against it.
Names: Types PascalCase, functions/methods lower_snake or lowerCamel consistent with the surrounding file, constants kCamel or UPPER_SNAKE.
Comments explain intent and non-obvious hardware/format facts. Never delete intent comments.
No magic numbers for format offsets without a named constant or an explaining comment.

## Prohibited
No opportunistic refactoring outside task scope.
No TODO/FIXME unless the task authorizes it.
No API changes unless the task authorizes them.
